-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: vueling
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `vueling`
--


--
-- Table structure for table `avions`
--

DROP TABLE IF EXISTS `avions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avions` (
  `id_avio` int(5) NOT NULL AUTO_INCREMENT,
  `capacitat` int(11) NOT NULL,
  `model` varchar(20) NOT NULL,
  PRIMARY KEY (`id_avio`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avions`
--

LOCK TABLES `avions` WRITE;
/*!40000 ALTER TABLE `avions` DISABLE KEYS */;
INSERT INTO `avions` VALUES (1,240,'Airbus A320'),(2,380,'Airbus 380'),(3,210,'Boeng 717'),(4,380,'Airbus 380');
/*!40000 ALTER TABLE `avions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seients`
--

DROP TABLE IF EXISTS `seients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seients` (
  `id_seient` int(255) NOT NULL AUTO_INCREMENT,
  `id_avio` int(5) NOT NULL,
  `seient_avio` varchar(4) NOT NULL,
  PRIMARY KEY (`id_seient`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seients`
--

LOCK TABLES `seients` WRITE;
/*!40000 ALTER TABLE `seients` DISABLE KEYS */;
INSERT INTO `seients` VALUES (1,1,'1A'),(2,1,'1B'),(3,1,'1C'),(4,2,'1A'),(5,2,'1B'),(6,2,'1C');
/*!40000 ALTER TABLE `seients` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-14 18:50:20

