-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: culdampolla
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `culdampolla`
--


--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id_client` int(5) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `adresa` varchar(20) NOT NULL,
  `telefon` varchar(10) NOT NULL,
  `correu` varchar(20) NOT NULL,
  `data_registre` date NOT NULL,
  `recomanat_per` int(5) NOT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Pepitu Gafotes','muntaner 445, 4 -4 ','64664664','gui@gmail.com','2020-04-02',0),(2,'Manuel Gafo','Aribau 445, 4 -4 ','64664646','manel@hotmail.com','2020-04-30',1);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveidor`
--

DROP TABLE IF EXISTS `proveidor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveidor` (
  `id_proveidor` int(5) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `ad_carrer` varchar(50) NOT NULL,
  `ad_numero` int(11) NOT NULL,
  `ad_pis` int(5) NOT NULL,
  `ad_porta` int(5) NOT NULL,
  `ad_ciutat` varchar(20) NOT NULL,
  `ad_codipostal` varchar(10) NOT NULL,
  `ad_pais` varchar(20) NOT NULL,
  `telefon` varchar(10) NOT NULL,
  `fax` varchar(10) NOT NULL,
  `NIF` varchar(10) NOT NULL,
  PRIMARY KEY (`id_proveidor`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveidor`
--

LOCK TABLES `proveidor` WRITE;
/*!40000 ALTER TABLE `proveidor` DISABLE KEYS */;
INSERT INTO `proveidor` VALUES (1,'Gafas pijas italiana','Galatea',5,1,2,'Milano','332323','Italia','2532523523','253325523','IT25253523'),(5,'Gafas Chinas','ni hao',33,3,5,'Shanghai','2333','China','434342','4322','C746644');
/*!40000 ALTER TABLE `proveidor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ulleres`
--

DROP TABLE IF EXISTS `ulleres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ulleres` (
  `id_ullera` int(5) NOT NULL AUTO_INCREMENT,
  `marca` varchar(20) NOT NULL,
  `proveidor` int(5) NOT NULL,
  `grad_vidres` int(11) NOT NULL,
  `muntura` set('flotant','pasta','metalica','') NOT NULL DEFAULT 'pasta',
  `color_mu` varchar(20) NOT NULL,
  `color_vidre` varchar(20) NOT NULL,
  `preu` int(10) NOT NULL,
  PRIMARY KEY (`id_ullera`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ulleres`
--

LOCK TABLES `ulleres` WRITE;
/*!40000 ALTER TABLE `ulleres` DISABLE KEYS */;
INSERT INTO `ulleres` VALUES (1,'Rayban',1,2,'pasta','blau','fosques',90),(2,'Fukis',2,0,'metalica','negre','transparent',20),(3,'Fukis',2,5,'pasta','negra','transparent',35),(4,'Fukis',2,5,'pasta','negra','transparent',35);
/*!40000 ALTER TABLE `ulleres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendes`
--

DROP TABLE IF EXISTS `vendes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendes` (
  `id_venda` int(5) NOT NULL AUTO_INCREMENT,
  `ullera` int(5) NOT NULL,
  `client` int(5) NOT NULL,
  `empleat` varchar(20) NOT NULL,
  PRIMARY KEY (`id_venda`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendes`
--

LOCK TABLES `vendes` WRITE;
/*!40000 ALTER TABLE `vendes` DISABLE KEYS */;
INSERT INTO `vendes` VALUES (1,3,1,'pepito'),(2,2,2,'manel'),(3,4,1,'pepito'),(4,1,2,'pepito');
/*!40000 ALTER TABLE `vendes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-15 10:16:17

